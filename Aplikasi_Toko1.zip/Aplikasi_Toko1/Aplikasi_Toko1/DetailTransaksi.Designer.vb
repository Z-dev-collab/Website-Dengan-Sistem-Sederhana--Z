﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DetailTransaksi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DGV_Detail = New System.Windows.Forms.DataGridView()
        Me.btnCetak = New System.Windows.Forms.Button()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        CType(Me.DGV_Detail, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DGV_Detail
        '
        Me.DGV_Detail.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DGV_Detail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGV_Detail.Location = New System.Drawing.Point(112, 88)
        Me.DGV_Detail.Name = "DGV_Detail"
        Me.DGV_Detail.ReadOnly = True
        Me.DGV_Detail.RowTemplate.Height = 28
        Me.DGV_Detail.Size = New System.Drawing.Size(550, 326)
        Me.DGV_Detail.TabIndex = 0
        '
        'btnCetak
        '
        Me.btnCetak.Location = New System.Drawing.Point(112, 433)
        Me.btnCetak.Name = "btnCetak"
        Me.btnCetak.Size = New System.Drawing.Size(161, 40)
        Me.btnCetak.TabIndex = 1
        Me.btnCetak.Text = "Cetak Transaksi"
        Me.btnCetak.UseVisualStyleBackColor = True
        '
        'PrintDocument1
        '
        '
        'DetailTransaksi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(762, 498)
        Me.Controls.Add(Me.btnCetak)
        Me.Controls.Add(Me.DGV_Detail)
        Me.Name = "DetailTransaksi"
        Me.Text = "DetailTransaksi"
        CType(Me.DGV_Detail, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DGV_Detail As System.Windows.Forms.DataGridView
    Friend WithEvents btnCetak As System.Windows.Forms.Button
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
End Class
