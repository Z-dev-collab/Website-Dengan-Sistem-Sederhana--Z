﻿Imports MySql.Data.MySqlClient '

Module Koneksi
    Public conn As MySqlConnection
    Public cmd As MySqlCommand
    Public adapter As MySqlDataAdapter
    Public ds As DataSet

    Public Sub BukaDB()
        Try
            ' Sesuaikan database=toko dengan nama database kamu di XAMPP
            conn = New MySqlConnection("server=localhost;user id=root;password=;database=toko1")
            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If
        Catch ex As Exception
            MsgBox("Koneksi Database Gagal: " & ex.Message)
        End Try
    End Sub
End Module