﻿Imports MySql.Data.MySqlClient
Imports System.Drawing.Printing

Public Class DetailTransaksi
    Dim conn As MySqlConnection
    Dim adapter As MySqlDataAdapter
    Dim ds As DataSet

    Sub BukaDB()
        Try
            Dim db As String = "server=localhost;user id=root;password=;database=toko1"
            conn = New MySqlConnection(db)
            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If
        Catch ex As Exception
            MsgBox("Koneksi Error: " & ex.Message)
        End Try
    End Sub

    Sub TampilDetail()
        Try
            Call BukaDB()
            Dim query As String = "SELECT * FROM detail_transaksi ORDER BY nomor_transaksi DESC"
            adapter = New MySqlDataAdapter(query, conn)
            ds = New DataSet
            ds.Clear()
            adapter.Fill(ds, "detail")
            DGV_Detail.DataSource = ds.Tables("detail")
            DGV_Detail.ReadOnly = True
        Catch ex As Exception
            MsgBox("Gagal Tampil: " & ex.Message)
        End Try
    End Sub

    Private Sub DetailTransaksi_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call TampilDetail()
    End Sub

    Private Sub btnCetak_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCetak.Click
        PrintDocument1.Print()
    End Sub

   Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim g As Graphics = e.Graphics
        Dim fJudul As New Font("Courier New", 14, FontStyle.Bold)
        Dim fNormal As New Font("Courier New", 10)
        Dim fBold As New Font("Courier New", 10, FontStyle.Bold)
        Dim y As Integer = 50
        Dim total As Double = 0

        ' Header Struk
        g.DrawString("STRUK PEMBAYARAN TOKO", fJudul, Brushes.Black, 50, y)
        y = y + 30
        g.DrawString("---------------------------------------------------------------", fNormal, Brushes.Black, 50, y)
        y = y + 20

        ' Judul Kolom
        g.DrawString("Barang", fBold, Brushes.Black, 50, y)
        g.DrawString("Harga", fBold, Brushes.Black, 250, y)
        g.DrawString("Qty", fBold, Brushes.Black, 400, y)
        g.DrawString("Subtotal", fBold, Brushes.Black, 500, y)
        y = y + 20
        g.DrawString("---------------------------------------------------------------", fNormal, Brushes.Black, 50, y)
        y = y + 20

        ' PERBAIKAN: Menggunakan Rows (semua baris) bukan SelectedRows
        For Each r As DataGridViewRow In DGV_Detail.Rows
            ' Cek supaya baris kosong di paling bawah tidak ikut diproses
            If Not r.IsNewRow Then
                ' Ambil data sesuai urutan kolom di Screenshot 2026-05-04 105630.jpg
                Dim n As String = CStr(r.Cells(2).FormattedValue) ' Kolom nama
                Dim h As Double = Val(r.Cells(3).Value)           ' Kolom harga_beli
                Dim q As Integer = Val(r.Cells(4).Value)          ' Kolom jumlah[cite: 1]
                Dim s As Double = h * q

                ' Cetak data menyamping
                g.DrawString(n, fNormal, Brushes.Black, 50, y)
                g.DrawString(h.ToString("N0"), fNormal, Brushes.Black, 250, y)
                g.DrawString(q.ToString(), fNormal, Brushes.Black, 400, y)
                g.DrawString(s.ToString("N0"), fNormal, Brushes.Black, 500, y)

                y = y + 20
                total = total + s
            End If
        Next

        ' Footer & Total
        g.DrawString("---------------------------------------------------------------", fNormal, Brushes.Black, 50, y)
        y = y + 20
        g.DrawString("TOTAL: Rp " & total.ToString("N0"), fBold, Brushes.Black, 350, y)
        y = y + 40
        g.DrawString("Terima Kasih, Jo!", fNormal, Brushes.Black, 50, y)
    End Sub
End Class