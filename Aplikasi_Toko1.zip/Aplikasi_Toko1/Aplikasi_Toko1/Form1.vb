﻿Imports MySql.Data.MySqlClient

Public Class Form1
    Public conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim adapter As MySqlDataAdapter
    Dim ds As DataSet
    Dim WithEvents DGV As New DataGridView
    Sub BukaDB()
        Try
            conn = New MySqlConnection("server=localhost;user id=root;password=;database=toko1")
            If conn.State = ConnectionState.Closed Then conn.Open()
        Catch ex As Exception
            MsgBox("Koneksi Error: " & ex.Message)
        End Try
    End Sub

    Sub TampilData()
        Try
            Call BukaDB()
            adapter = New MySqlDataAdapter("SELECT * FROM barang", conn)
            ds = New DataSet
            ds.Clear()
            adapter.Fill(ds, "barang")
            DGV.DataSource = ds.Tables("barang")
        Catch ex As Exception
            MsgBox("Gagal Tampil: " & ex.Message)
        End Try
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        With DGV
            .Name = "DGV"
            .Location = New Point(350, 60)
            .Size = New Size(450, 300)
            .ReadOnly = True
            .SelectionMode = DataGridViewSelectionMode.FullRowSelect
            .AllowUserToAddRows = False
            .AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        End With

        If Not Me.Controls.Contains(DGV) Then
            Me.Controls.Add(DGV)
        End If

        Call TampilData()
    End Sub
    Private Sub DGV_CellDoubleClick(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs) Handles DGV.CellDoubleClick
        If e.RowIndex >= 0 Then
            Transaksi.txtKodeBarang.Text = DGV.Rows(e.RowIndex).Cells(0).Value.ToString
            Transaksi.txtNamaBarang.Text = DGV.Rows(e.RowIndex).Cells(1).Value.ToString
            Transaksi.txtHarga.Text = DGV.Rows(e.RowIndex).Cells(4).Value.ToString

            Transaksi.Show()
            Transaksi.txtJumlah.Focus()
        End If
    End Sub

    ' --- TOMBOL SIMPAN BARANG BARU ---
    Private Sub btnSimpan_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSimpan.Click
        If txtNama.Text = "" Or txtStok.Text = "" Or txtHargaJual.Text = "" Then
            MsgBox("Isi data barang dengan lengkap!")
            Exit Sub
        End If

        Try
            Call BukaDB()
            Dim sql As String = "INSERT INTO barang (nama, stok, harga_beli, harga_jual) VALUES " & _
                                "('" & txtNama.Text & "', '" & txtStok.Text & "', '" & txtHargaBeli.Text & "', '" & txtHargaJual.Text & "')"
            cmd = New MySqlCommand(sql, conn)
            cmd.ExecuteNonQuery()

            MsgBox("Barang berhasil ditambah!")
            Call TampilData()
            Call KosongkanForm()
        Catch ex As Exception
            MsgBox("Simpan Gagal: " & ex.Message)
        End Try
    End Sub
    Private Sub btnKeTransaksi_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnKeTransaksi.Click
        Transaksi.Show()
    End Sub
    Private Sub btnDetail_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDetail.Click
        DetailTransaksi.Show()
    End Sub

    Sub KosongkanForm()
        txtNama.Clear() : txtStok.Clear() : txtHargaBeli.Clear() : txtHargaJual.Clear()
        txtNama.Focus()
    End Sub
End Class