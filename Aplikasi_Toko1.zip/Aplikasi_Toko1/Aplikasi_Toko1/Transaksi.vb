﻿Imports MySql.Data.MySqlClient

Public Class Transaksi
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim WithEvents DGV_Transaksi As New DataGridView

    Sub BukaDB()
        Try
            conn = New MySqlConnection("server=localhost;user id=root;password=;database=toko1")
            If conn.State = ConnectionState.Closed Then conn.Open()
        Catch ex As Exception
            MsgBox("Koneksi Gagal: " & ex.Message)
        End Try
    End Sub
    Sub NomorOtomatis()
        Try
            Call BukaDB()
            cmd = New MySqlCommand("SELECT nomor_transaksi FROM transaksi ORDER BY nomor_transaksi DESC LIMIT 1", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If dr.HasRows Then
                txtNoFaktur.Text = Val(dr.Item("nomor_transaksi")) + 1
            Else
                txtNoFaktur.Text = "1"
            End If
        Catch ex As Exception
            txtNoFaktur.Text = "1"
        Finally
            If dr IsNot Nothing Then dr.Close()
            conn.Close()
        End Try
    End Sub

    Sub BuatTabel()
        DGV_Transaksi.Columns.Clear()
        DGV_Transaksi.Columns.Add("Kode", "Kode")
        DGV_Transaksi.Columns.Add("Nama", "Nama Barang")
        DGV_Transaksi.Columns.Add("Harga", "Harga")
        DGV_Transaksi.Columns.Add("Qty", "Qty")
        DGV_Transaksi.Columns.Add("Subtotal", "Subtotal")
        With DGV_Transaksi
            .AllowUserToAddRows = False
            .Location = New Point(650, 55)
            .Size = New Size(550, 280)
            .BackgroundColor = Color.White
            .AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            .ReadOnly = True
        End With
        If Not Me.Controls.Contains(DGV_Transaksi) Then Me.Controls.Add(DGV_Transaksi)
    End Sub

    Private Sub Transaksi_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call BuatTabel()
        Call NomorOtomatis()
        txtTanggal.Text = Format(Now, "yyyy-MM-dd")
        txtNoFaktur.ReadOnly = True
        txtTanggal.Enabled = False

        txtNamaBarang.ReadOnly = True
        txtHarga.ReadOnly = True
        txtKembali.ReadOnly = True
        txtNoFaktur.BackColor = Color.LightGray
        txtNamaBarang.BackColor = Color.LightGray
        txtHarga.BackColor = Color.LightGray
        lblTotal.AutoSize = False
        lblTotal.TextAlign = ContentAlignment.MiddleRight
        lblTotal.Size = New Size(550, 80)
        lblTotal.Location = New Point(650, 350)
        lblTotal.Text = "Rp 0"
        lblTotal.Font = New Font("Arial", 45, FontStyle.Bold)
        lblTotal.ForeColor = Color.Red
    End Sub

    Sub CariBarang()
        If txtKodeBarang.Text.Trim = "" Then Exit Sub
        Try
            Call BukaDB()
            ' Sesuai Screenshot 2026-05-03 233535.jpg: kode adalah int(11)
            cmd = New MySqlCommand("SELECT * FROM barang WHERE kode = " & Val(txtKodeBarang.Text.Trim), conn)
            dr = cmd.ExecuteReader()
            If dr.Read() Then
                txtNamaBarang.Text = dr("nama").ToString()
                txtHarga.Text = dr("harga_jual").ToString()
                txtJumlah.Focus()
            Else
                MsgBox("Barang Tidak Ditemukan!")
                txtKodeBarang.Clear()
                txtKodeBarang.Focus()
            End If
        Catch ex As Exception
            MsgBox("Error Cari: " & ex.Message)
        Finally
            If dr IsNot Nothing Then dr.Close()
            conn.Close()
        End Try
    End Sub

    Private Sub btnCari_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnCari.Click
        Call CariBarang()
    End Sub

    Private Sub txtKodeBarang_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles txtKodeBarang.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            Call CariBarang()
        End If
    End Sub

    Sub HitungTransaksi()
        Dim tGrid As Double = 0
        For i As Integer = 0 To DGV_Transaksi.Rows.Count - 1
            tGrid += CDbl(DGV_Transaksi.Rows(i).Cells(4).Value)
        Next
        lblTotal.Text = "Rp " & Format(tGrid, "n0")

        Dim tBayar As Double = Val(txtBayar.Text)
        If tBayar >= tGrid Then
            txtKembali.Text = Format(tBayar - tGrid, "n0")
        Else
            txtKembali.Text = "0"
        End If
    End Sub

    Private Sub txtBayar_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtBayar.TextChanged
        Call HitungTransaksi()
    End Sub

    Private Sub btnTambah_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnTambah.Click
        If txtNamaBarang.Text = "" Or txtJumlah.Text = "" Then
            MsgBox("Pilih barang dan isi jumlahnya dulu!")
            Exit Sub
        End If

        Dim subtotal As Double = CDbl(txtHarga.Text) * Val(txtJumlah.Text)
        DGV_Transaksi.Rows.Add(txtKodeBarang.Text, txtNamaBarang.Text, txtHarga.Text, txtJumlah.Text, subtotal)
        Call HitungTransaksi()

        ' Reset field input bantu
        txtKodeBarang.Clear() : txtNamaBarang.Clear() : txtHarga.Clear() : txtJumlah.Clear() : txtKodeBarang.Focus()
    End Sub

    Private Sub btnSimpan_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSimpan.Click
        ' Validasi jika keranjang kosong
        If DGV_Transaksi.Rows.Count = 0 Then
            MsgBox("Keranjang belanja masih kosong, Jo!")
            Exit Sub
        End If

        Try
            Call BukaDB()

            ' 1. HITUNG TOTAL BELANJA
            Dim murniTotal As Double = 0
            For i As Integer = 0 To DGV_Transaksi.Rows.Count - 1
                murniTotal += CDbl(DGV_Transaksi.Rows(i).Cells(4).Value)
            Next

            ' 2. SIMPAN KE TABEL TRANSAKSI (Master)
            ' Field: tanggal_transaksi, total
            Dim sqlMaster As String = "INSERT INTO transaksi (tanggal_transaksi, total) VALUES ('" & txtTanggal.Text & "', " & murniTotal & ")"
            cmd = New MySqlCommand(sqlMaster, conn)
            cmd.ExecuteNonQuery()

            ' 3. AMBIL ID TRANSAKSI TERAKHIR (Untuk menghubungkan ke detail)
            cmd = New MySqlCommand("SELECT LAST_INSERT_ID()", conn)
            Dim idBaru As Integer = cmd.ExecuteScalar

            ' 4. SIMPAN SEMUA BARANG KE TABEL DETAIL_TRANSAKSI (Sesuai Field Screenshot Kamu)
            ' Field: nomor_transaksi, kode, nama, harga_beli, jumlah, payment
            For i As Integer = 0 To DGV_Transaksi.Rows.Count - 1
                Dim sqlDetail As String = "INSERT INTO detail_transaksi (nomor_transaksi, kode, nama, harga_beli, jumlah, payment) VALUES (" & _
                    idBaru & ", " & _
                    "'" & DGV_Transaksi.Rows(i).Cells(0).Value & "', " & _
                    "'" & DGV_Transaksi.Rows(i).Cells(1).Value & "', " & _
                    "'" & DGV_Transaksi.Rows(i).Cells(2).Value & "', " & _
                    "'" & DGV_Transaksi.Rows(i).Cells(3).Value & "', " & _
                    "'Cash')" ' Default payment diset Cash, bisa diganti sesuai pilihan di form

                cmd = New MySqlCommand(sqlDetail, conn)
                cmd.ExecuteNonQuery()
            Next

            MsgBox("Data Berhasil Disimpan ke Transaksi dan Detail!", MsgBoxStyle.Information)

            ' Setelah simpan, langsung kosongkan form
            Call btnRefresh_Click(Nothing, Nothing)

        Catch ex As Exception
            MsgBox("Error saat simpan: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnRefresh.Click
        txtKodeBarang.Clear()
        txtNamaBarang.Clear()
        txtHarga.Clear()
        txtJumlah.Clear()
        txtBayar.Clear()
        txtKembali.Clear()
        lblTotal.Text = "Rp 0"
        DGV_Transaksi.Rows.Clear()
        Call NomorOtomatis()
        txtKodeBarang.Focus()
    End Sub

    Private Sub btnKembali_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnKembali.Click
        Me.Close()
    End Sub
End Class