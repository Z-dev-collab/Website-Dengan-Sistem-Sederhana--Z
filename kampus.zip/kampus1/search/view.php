<?php
include '../config/koneksi.php';
?>
<div class="content">

    <!-- Bagian 1 : Data Mahasiswa -->
    <div class="data-siswa">
        <div class="header-table">
            <h2>Mencari Data Mahasiswa</h2>
            <form method="GET" action="" style="display: flex; gap: 10px; align-items: center; max-width: 500px;">
                <input type="hidden" name="page" value="view_search">
                <input type="text" name="data_mahasiswa" class="search" placeholder="Cari Nama Mahasiswa" style="margin: 0;"
                       value="<?php echo isset($_GET['data_mahasiswa']) ? htmlspecialchars($_GET['data_mahasiswa']) : ''; ?>">
                <button type="submit" class="btn-submit" style="flex: none; padding: 10px 20px; margin: 0;">Cari</button>
            </form>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Nama Mahasiswa</th>
                    <th>Jurusan</th>
                    <th>Mata Kuliah</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (isset($_GET['data_mahasiswa']) && $_GET['data_mahasiswa'] !== '') {
                    $nama = mysqli_real_escape_string($conn, $_GET['data_mahasiswa']);
                    $query = "SELECT m.nama, m.jurusan, d.nama_mapel
                              FROM data_mahasiswa m
                              JOIN mata_kuliah d ON m.id_mapel = d.id_mapel
                              WHERE m.nama LIKE '%$nama%'";
                    $result = mysqli_query($conn, $query);
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>
                                    <td>{$row['nama']}</td>
                                    <td>{$row['jurusan']}</td>
                                    <td>{$row['nama_mapel']}</td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>Tidak ada nama_dosen ditemukan di Data Mahasiswa tersebut.</td></tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>Masukkan Nama Data Mahasiswa untuk melihat daftar mahasiswa.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <!-- Bagian 2 : Posisi Sebuah Buku -->
    <div class="data-siswa">
        <div class="header-table">
            <h2>Mencari Data Dosen</h2>
            <form method="GET" action="" style="display: flex; gap: 10px; align-items: center; max-width: 500px;">
                <input type="hidden" name="page" value="view_search">
                <input type="text" name="nama_dosen" class="search" placeholder="Cari Nama Dosen" style="margin: 0;"
                       value="<?php echo isset($_GET['nama_dosen']) ? htmlspecialchars($_GET['nama_dosen']) : ''; ?>">
                <button type="submit" class="btn-submit" style="flex: none; padding: 10px 20px; margin: 0;">Cari</button>
            </form>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Nama Dosen</th>
                    <th>Nomor Hp</th>
                    <th>Alamat</th>
                    <th>Mata Kuliah</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (isset($_GET['nama_dosen']) && $_GET['nama_dosen'] !== '') {
                    $nama_dosen = mysqli_real_escape_string($conn, $_GET['nama_dosen']);
                    $query2 = "SELECT n.nama_dosen, n.nomor_hp, n.alamat, d.nama_mapel
                               FROM nama_dosen n
                               JOIN mata_kuliah d ON n.id_mapel = d.id_mapel
                               WHERE n.nama_dosen LIKE '%$nama_dosen%'";
                    $result2 = mysqli_query($conn, $query2);
                    if (mysqli_num_rows($result2) > 0) {
                        while ($row = mysqli_fetch_assoc($result2)) {
                            echo "<tr>
                                    <td>{$row['nama_dosen']}</td>
                                    <td>{$row['nomor_hp']}</td>
                                    <td>{$row['alamat']}</td>
                                    <td>{$row['nama_mapel']}</td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>Nama Dosen tersebut tidak ditemukan.</td></tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>Masukkan Nama Dosen untuk mengetahui posisinya.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
</div>
