<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout - Sistem Informasi</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            /* Menambahkan background gambar UIS */
            background-image: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS80m-rYVdI_GZq_3Gv8JvW0fT0zF3jK5u9tg&s');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            font-family: 'Poppins', Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container {
            width: 400px;
            background: rgba(255, 255, 255, 0.85); /* Glassmorphism */
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0px 15px 35px rgba(0,0,0,0.2);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #111;
            font-size: 26px;
            font-weight: 700;
        }

        h2::after {
            content: '';
            display: block;
            width: 50px;
            height: 4px;
            background: linear-gradient(90deg, #006837, #efa00b);
            margin: 10px auto 0;
            border-radius: 2px;
        }
        
        .alert-logout {
            background-color: rgba(212, 237, 218, 0.9);
            color: #155724;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 25px;
            font-size: 14px;
            text-align: center;
            border: 1px solid #c3e6cb;
            font-weight: 600;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #333;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        input[type="text"],
        input[type="password"],
        select {
            width: 100%;
            padding: 14px 16px;
            border: 1px solid rgba(255, 255, 255, 0.5);
            border-radius: 10px;
            font-size: 15px;
            background: rgba(255, 255, 255, 0.7);
            transition: all 0.3s ease;
            font-family: 'Poppins', Arial, sans-serif;
        }

        input:focus, select:focus {
            border-color: #006837;
            background: #fff;
            outline: none;
            box-shadow: 0 0 0 4px rgba(0,104,55,0.1);
        }

        .btn-submit {
            background: linear-gradient(135deg, #006837, #004d26);
            color: white;
            padding: 15px;
            border: none;
            width: 100%;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            font-size: 16px;
            transition: all 0.3s ease;
            margin-top: 15px;
            box-shadow: 0 4px 15px rgba(0, 104, 55, 0.3);
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 104, 55, 0.4);
        }

        .btn-submit:active {
            transform: translateY(0);
        }

        .footer-link {
            text-align: center;
            margin-top: 25px;
            font-size: 14px;
            color: #444;
        }

        .footer-link a {
            color: #006837;
            text-decoration: none;
            font-weight: 700;
            transition: color 0.3s ease;
        }

        .footer-link a:hover {
            color: #efa00b;
        }
    </style>
</head>
<body>

    <div class="form-container">
        <div class="alert-logout">
            Logout Berhasil! <br> Silahkan login kembali.
        </div>

        <h2>Login Pengguna</h2>

        <form action="proses_login.php" method="POST" autocomplete="off">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="Username Anda" autocomplete="off" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Masukkan Password Anda" autocomplete="new-password" required>
            </div>

            <button type="submit" class="btn-submit">Masuk Kembali</button>
        </form>

        <div class="footer-link">
            Lupa Password? <a href="https://wa.me/6285835153723?text=Halo%20Admin%2C%20saya%20lupa%20kata%20sandi">Hubungi Admin</a>
        </div>
    </div>

</body>
</html>