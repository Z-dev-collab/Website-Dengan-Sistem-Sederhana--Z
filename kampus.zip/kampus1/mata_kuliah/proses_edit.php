<?php
include '../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_mapel     = $_POST['id_mapel'];
    $nama_mapel   = $_POST['nama_mapel'];
    $jumlah_sks   = $_POST['jumlah_sks'];

    $query = "UPDATE mata_kuliah SET 
                nama_mapel='$nama_mapel',
                jumlah_sks='$jumlah_sks'
                WHERE id_mapel = '$id_mapel'";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Data Mata Kuliah berhasil diperbarui!'); window.location.href='../?page=view_mata_kuliah';</script>";
    } else {
        echo "<script>alert('Gagal mengupdate data: " . mysqli_error($conn) . "'); window.history.back();</script>";
    }
} else {
    header("Location: ../?page=view_mata_kuliah");
    exit;
}
?>
