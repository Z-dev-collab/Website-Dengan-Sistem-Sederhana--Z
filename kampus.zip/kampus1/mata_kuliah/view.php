<div class="content">
    <div class="data-siswa">
        <div class="header-table">
            <h2>Data Mata Kuliah</h2>
            <a href="?page=tambah_mata_kuliah" class="btn-tambah">+ Tambah Data Mata Kuliah</a>
        </div>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Mata Kuliah</th>
                        <th>Nama Mata Kuliah</th>
                        <th>Jumlah Satuan Kredit Semester</th>
                        <th>Aksi</th>
                    </tr>   
                </thead>
                <tbody>
                <?php
                // ambil data barang_masuk
                // $query = "SELECT * FROM barang_masuk ORDER BY tanggal_masuk ASC";
                $query = "SELECT * FROM mata_kuliah ORDER BY nama_mapel ASC";
                $result = mysqli_query($conn, $query);
                $no = 1;

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                                <td>".$no++."</td>
                                <td>".$row['id_mapel']."</td>
                                <td>".$row['nama_mapel']."</td>
                                <td>".$row['jumlah_sks']."</td>
                                <td class='table-action'>
                                    <a class='btn-edit' href='?page=edit_mata_kuliah&id_mapel=".$row['id_mapel']."' text-decoration:none;'>Edit</a> 
                                    <a class='btn-hapus' href='mata_kuliah/hapus.php?id_mapel=".$row['id_mapel']."' 
                                       text-decoration:none;' 
                                       onclick=\"return confirm('Yakin ingin menghapus data ini?');\">Hapus</a>
                                </td>
                              </tr>";
                    }
                } else {
                    echo "<tr>
                            <td colspan='8' style='text-align:center;'>Data Barang Masuk belum tersedia.</td>
                          </tr>";
                }

                // tutup koneksi
                mysqli_close($conn);
                ?>
            </tbody>
            </table>
    </div>
</div>