<?php
// koneksi ke database
include '../config/koneksi.php'; // pastikan file config.php berisi koneksi ke database


// cek apakah form disubmit dengan method POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ambil data dari form
    $nama_mapel     = mysqli_real_escape_string($conn, $_POST['nama_mapel']);
    $jumlah_sks     = mysqli_real_escape_string($conn, $_POST['jumlah_sks']);

    // validasi sederhana: cek jika ada yang kosong
    if (empty($nama_mapel)|| empty($jumlah_sks)) {
        echo "<script>alert('Semua field harus diisi!'); window.location.href='../?page=tambah_mata_kuliah';</script>";
        exit;
    }

    // query insert data        
    $query = "INSERT INTO mata_kuliah (nama_mapel, jumlah_sks)
              VALUES ('$nama_mapel', '$jumlah_sks')";

    if (mysqli_query($conn, $query)) {
        // jika sukses
        echo "<script>alert('Data Mata Kuliah berhasil ditambahkan!'); window.location.href='../?page=view_mata_kuliah';</script>";
    } else {
        // jika gagal
        echo "<script>alert('Gagal menambahkan Data Mata Kuliah: " . mysqli_error($conn) . "'); window.location.href='../?page=tambah_mata_kuliah';</script>";
    }

    // tutup koneksi
    mysqli_close($conn);
} else {
    // jika akses langsung tanpa submit
    header("Location: ../?page=view_mata_kuliah");
    exit;
}
?>
