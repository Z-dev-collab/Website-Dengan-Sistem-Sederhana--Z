<?php
include '../config/koneksi.php';

// Ambil data berdasarkan ID yang dikirim dari tombol Edit
if (isset($_GET['id_mapel'])) {
    $id_mapel = $_GET['id_mapel'];
    $query = "SELECT d.id_mapel, d.nama_mapel, d.jumlah_sks FROM mata_kuliah AS d
                WHERE d.id_mapel = '$id_mapel'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $data = mysqli_fetch_assoc($result); 
    } else {
        echo "<script>alert('Data Mata Kuliah tidak ditemukan!'); window.location.href='?page=view_mata_kuliah';</script>";
        exit;
    }
} else {
    echo "<script>alert('ID Mata Kuliah tidak ditemukan!'); window.location.href='?page=view_mata_kuliah';</script>";
    exit;
}
?>

<div class="content">
    <div class="form-container">
        <h2>Edit Data Mata Kuliah</h2>
        <form action="mata_kuliah/proses_edit.php" method="POST">

            <!-- ID hidden untuk proses update -->
            <input type="hidden" name="id_mapel" value="<?= $data['id_mapel']; ?>">

            <div class="form-group">
                <label for="nama_mapel">Nama Mata Kuliah</label>
                <input type="text" id="nama_mapel" name="nama_mapel" value="<?= $data['nama_mapel']; ?>" required>
            </div>

            <div class="form-group">
                <label for="jumlah_sks">Jumlah Satuan Kredit Semester (SKS)</label>
                <input type="text" id="jumlah_sks" name="jumlah_sks" value="<?= $data['jumlah_sks']; ?>" required>
            </div>

            <div class="button-group">
                <button type="submit" class="btn-submit">Simpan</button>
                <a href="?page=view_mata_kuliah" class="btn-back">Kembali</a>
            </div>
        </form>
    </div>
</div>
