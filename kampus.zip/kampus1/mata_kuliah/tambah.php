<div class="content">
    <div class="form-container">
        <h2>Tambah Data Mata Kuliah</h2>
        <form action="mata_kuliah/proses_tambah.php" method="POST">
            
            <div class="form-group">
                <label for="nama_mapel">Nama Mata Kuliah</label>
                <input type="text" id="nama_mapel" name="nama_mapel" placeholder="Masukkan Nama Mata Kuliah" required>
            </div>

            <div class="form-group">
                <label for="jumlah_sks">Jumlah Satuan Kredit Semester</label>
                <input type="text" id="jumlah_sks" name="jumlah_sks" placeholder="Masukkan Jumlah Sks" required>
            </div>

            <div class="button-group">
                <button type="submit" class="btn-submit">Simpan</button>
                <a href="?page=view_mata_kuliah" class="btn-back">Kembali</a>
            </div>
        </form>
    </div>
</div>
