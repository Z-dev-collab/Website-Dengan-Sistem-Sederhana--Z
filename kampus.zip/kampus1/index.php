<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">

<?php
    include 'config/koneksi.php';
    include 'template/header.php';
    include 'template/sidebar.php';
?>        

<?php
session_start();
if (!isset($_SESSION['login'])){
	header("location: login.php");
	exit;
}
?>

<?php

error_reporting(0);
switch ($_GET['page']) {
	default:
			include 'template/content.php';
		break;

	case 'dashboard';
		 include 'template/content.php';
	break;
	
// link menu siswa ==========================================

	case 'view_data_mahasiswa';
			 include 'data_mahasiswa/view.php';
	break;

    case 'tambah_data_mahasiswa';
			 include 'data_mahasiswa/tambah.php';
	break;

    case 'edit_data_mahasiswa';
			 include 'data_mahasiswa/edit.php';
	break;

	// link menu mata kuliah ==========================================

	case 'view_mata_kuliah';
			 include 'mata_kuliah/view.php';
	break;

    case 'tambah_mata_kuliah';
			 include 'mata_kuliah/tambah.php';
	break;

    case 'edit_mata_kuliah';
			 include 'mata_kuliah/edit.php';
	break;

	// link menu nama_dosen ==========================================

	case 'view_nama_dosen';
			 include 'nama_dosen/view.php';
	break;

    case 'tambah_nama_dosen';
			 include 'nama_dosen/tambah.php';
	break;

    case 'edit_nama_dosen';
			 include 'nama_dosen/edit.php';
	break;

	// link menu satuan kredit semester ==========================================

	case 'view_sks';
			 include 'sks/view.php';
	break;

    case 'tambah_sks';
			 include 'sks/tambah.php';
	break;

    case 'edit_sks';
			 include 'sks/edit.php';
	break;

	// link menu user ==========================================

	case 'view_user';
			 include 'user/view.php';
	break;

    case 'edit_user';
			 include 'user/edit.php';
	break;

	// link menu search ==========================================

	case 'view_search';
			 include 'search/view.php';
	break;

	
	// link menu bantuan ==========================================
	case 'view_bantuan';
			 include 'bantuan/view.php';
	break;

	// link menu login ==========================================

	case 'view_login';
			 include 'login/view.php';
	break;

}

?>
    </div>
</body>
</html>