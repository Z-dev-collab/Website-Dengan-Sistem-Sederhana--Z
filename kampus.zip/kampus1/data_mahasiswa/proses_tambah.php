<?php
// koneksi ke database
include '../config/koneksi.php'; // pastikan file config.php berisi koneksi ke database


// cek apakah form disubmit dengan method POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ambil data dari form
    $nama     = mysqli_real_escape_string($conn, $_POST['nama']);
    $jurusan    = mysqli_real_escape_string($conn, $_POST['jurusan']);
    $id_mapel  = mysqli_real_escape_string($conn, $_POST['id_mapel']);

    
    // validasi sederhana: cek jika ada yang kosong
    if (empty($nama) || empty($jurusan) || empty($id_mapel)) {
        echo "<script>alert('Semua field harus diisi!'); window.location.href='../?page=tambah_data_mahasiswa';</script>";
        exit;
    }

    // query insert data        
    $query = "INSERT INTO data_mahasiswa (nama, jurusan, id_mapel)
              VALUES ('$nama', '$jurusan', '$id_mapel')";

    if (mysqli_query($conn, $query)) {
        // jika sukses
        echo "<script>alert('Data Mahasiswa berhasil ditambahkan!'); window.location.href='../?page=view_data_mahasiswa';</script>";
    } else {
        // jika gagal
        echo "<script>alert('Gagal menambahkan data Mahasiswa: " . mysqli_error($conn) . "'); window.location.href='../?page=tambah_data_mahasiswa';</script>";
    }

    // tutup koneksi
    mysqli_close($conn);
} else {
    // jika akses langsung tanpa submit
    header("Location: ../?page=view_data_mahasiswa");
    exit;
}
?>
