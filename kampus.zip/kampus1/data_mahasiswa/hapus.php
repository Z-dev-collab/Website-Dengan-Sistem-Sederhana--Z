<?php
// koneksi ke database
include '../config/koneksi.php';

// ambil ID dari parameter URL
if (isset($_GET['id_mhs'])) {
    $id_mhs = $_GET['id_mhs'];

    // query hapus data
    $query = "DELETE FROM data_mahasiswa WHERE id_mhs='$id_mhs'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        // jika berhasil hapus, kembali ke halaman view_pemasukan
        header("Location: ../index.php?page=view_data_mahasiswa&pesan=hapus_sukses");
        exit;
    } else {
        echo "Gagal menghapus data: " . mysqli_error($conn);
    }
} else {
    echo "ID tidak ditemukan!";
}
?>
