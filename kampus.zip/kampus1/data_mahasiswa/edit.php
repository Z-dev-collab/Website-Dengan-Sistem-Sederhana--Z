<?php
include '../config/koneksi.php';

// Ambil data berdasarkan ID yang dikirim dari tombol Edit
if (isset($_GET['id_mhs'])) {
    $id_mhs = $_GET['id_mhs'];
    // Pastikan query mengambil id_mapel juga untuk logika 'selected' di dropdown
    $query = "SELECT m.id_mhs, m.nama, m.jurusan, m.id_mapel FROM data_mahasiswa AS m
                WHERE m.id_mhs = '$id_mhs'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $data = mysqli_fetch_assoc($result); 
    } else {
        echo "<script>alert('Data Mahasiswa tidak ditemukan!'); window.location.href='?page=view_data_mahasiswa';</script>";
        exit;
    }
} else {
    echo "<script>alert('ID Mahasiswa tidak ditemukan!'); window.location.href='?page=view_data_mahasiswa';</script>";
    exit;
}
?>

<div class="content">
    <div class="form-container">
        <h2>Edit Data Mahasiswa</h2>
        <form action="data_mahasiswa/proses_edit.php" method="POST">

            <!-- ID hidden untuk proses update -->
            <input type="hidden" name="id_mhs" value="<?= $data['id_mhs']; ?>">

            <div class="form-group">
                <label for="nama">Nama Mahasiswa</label>
                <input type="text" id="nama" name="nama" value="<?= $data['nama']; ?>" required>
            </div>

            <div class="form-group">
                <label for="jurusan">Jurusan</label>
                <input type="text" id="jurusan" name="jurusan" value="<?= $data['jurusan']; ?>" required>
            </div>

            <div class="form-group">
                <label for="id_mapel">Nama Mata Kuliah</label>
                <select name="id_mapel" id="id_mapel" required>
                    <option value="">-- Pilih Mata Kuliah --</option>
                    <?php 
                    $mata_kuliah = mysqli_query($conn, "SELECT * FROM mata_kuliah");
                    while($d = mysqli_fetch_assoc($mata_kuliah)) {
                        // Menentukan mata kuliah mana yang sedang aktif dipilih
                        $selected = ($d['id_mapel'] == $data['id_mapel']) ? "selected" : "";
                        echo "<option value='{$d['id_mapel']}' $selected>{$d['nama_mapel']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="button-group">
                <button type="submit" class="btn-submit">Simpan Perubahan</button>
                <a href="?page=view_data_mahasiswa" class="btn-back">Kembali</a>
            </div>
        </form>
    </div>
</div>