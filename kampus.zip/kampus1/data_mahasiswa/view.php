<div class="content">
    <div class="data-siswa">
        <div class="header-table">
            <h2>Data Mahasiswa</h2>
            <a href="?page=tambah_data_mahasiswa" class="btn-tambah">+ Tambah Data Mahasiswa</a>
        </div>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Mahasiswa</th>
                        <th>Jurusan</th>
                        <th>Mata Kuliah</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                // ambil data mahasiswa
                $query = "SELECT m.id_mhs, m.nama, m.jurusan, d.nama_mapel FROM data_mahasiswa AS m
                INNER JOIN mata_kuliah AS d ON m.id_mapel = d.id_mapel";
                $result = mysqli_query($conn, $query);
                $no = 1;

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                                <td>".$no++."</td>
                                <td>".$row['nama']."</td>
                                <td>".$row['jurusan']."</td>
                                <td>".$row['nama_mapel']."</td>
                                <td class='table-action'>
                                    <a class='btn-edit' href='?page=edit_data_mahasiswa&id_mhs=".$row['id_mhs']."' text-decoration:none;'>Edit</a> 
                                    <a class='btn-hapus' href='data_mahasiswa/hapus.php?id_mhs=".$row['id_mhs']."' 
                                       text-decoration:none;' 
                                       onclick=\"return confirm('Yakin ingin menghapus data ini?');\">Hapus</a>
                                </td>
                              </tr>";
                    }
                } else {
                    echo "<tr>
                            <td colspan='8' style='text-align:center;'>Data mahasiswa belum tersedia.</td>
                          </tr>";
                }

                // tutup koneksi
                mysqli_close($conn);
                ?>
            </tbody>
            </table>
    </div>
</div>