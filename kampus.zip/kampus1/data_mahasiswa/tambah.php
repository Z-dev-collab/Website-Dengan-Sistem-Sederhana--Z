<div class="content">
    <div class="form-container">
        <h2>Tambah Data Mahasiswa</h2>
        <form action="data_mahasiswa/proses_tambah.php" method="POST">
            
            <div class="form-group">
                <label for="nama">Nama Mahasiswa</label>
                <input type="text" id="nama" name="nama" placeholder="Masukkan Nama Mahasiswa" required>
            </div>

            <div class="form-group">
                <label for="jurusan">Jurusan Kuliah</label>
                <input type="text" id="jurusan" name="jurusan" placeholder="Masukkan Nama Jurusan" required>
            </div>

            <div class="form-group">
                <label for="id_mapel">Nama Mata Kuliah</label>
                <select name="id_mapel" id="id_mapel" required>
                    <option value="">-- Pilih Mata Kuliah --</option>
                    <?php 
                    $mata_kuliah = mysqli_query($conn, "SELECT * FROM mata_kuliah");
                    while($d = mysqli_fetch_assoc($mata_kuliah)) {
                        echo "<option value='{$d['id_mapel']}'>{$d['nama_mapel']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="button-group">
                <button type="submit" class="btn-submit">Simpan</button>
                <a href="?page=view_slot" class="btn-back">Kembali</a>
            </div>
        </form>
    </div>
</div>
