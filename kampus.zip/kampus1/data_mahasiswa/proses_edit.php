<?php
include '../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_mhs     = $_POST['id_mhs'];
    $nama       = $_POST['nama'];
    $jurusan   = $_POST['jurusan'];
    $id_mapel   = $_POST['id_mapel'];

    $query = "UPDATE data_mahasiswa SET 
                nama='$nama',
                jurusan='$jurusan',
                id_mapel='$id_mapel'
                WHERE id_mhs = '$id_mhs'";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Data barang masuk berhasil diperbarui!'); window.location.href='../?page=view_data_mahasiswa';</script>";
    } else {
        echo "<script>alert('Gagal mengupdate data: " . mysqli_error($conn) . "'); window.history.back();</script>";
    }
} else {
    header("Location: ../?page=data_mahasiswa");
    exit;
}
?>
