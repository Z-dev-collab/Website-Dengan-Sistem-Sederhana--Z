<div class="content">
    <div class="form-container">
        <h2>Tambah Data Nama Dosen</h2>
        <form action="nama_dosen/proses_tambah.php" method="POST">
            
            <div class="form-group">
                <label for="nama_dosen">Nama Dosen</label>
                <input type="text" id="nama_dosen" name="nama_dosen" placeholder="Masukkan Nama Dosen" required>
            </div>

            <div class="form-group">
                <label for="nomor_hp">Nomor Handphone</label>
                <input type="text" id="nomor_hp" name="nomor_hp" placeholder="Masukkan Nomor Hp" required>
            </div>

            <div class="form-group">
                <label for="alamat">Alamat</label>
                <input type="text" id="alamat" name="alamat" placeholder="Masukkan Alamat" required>
            </div>

            <div class="form-group">
                <label for="id_mapel">Mata Kuliah</label>
                <select name="id_mapel" id="id_mapel" required>
                    <option value="">-- Pilih Mata Kuliah --</option>
                    <?php 
                    $mata_kuliah = mysqli_query($conn, "SELECT * FROM mata_kuliah");
                    while($d = mysqli_fetch_assoc($mata_kuliah)) {
                        echo "<option value='{$d['id_mapel']}'>{$d['nama_mapel']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="button-group">
                <button type="submit" class="btn-submit">Simpan</button>
                <a href="?page=view_nama_dosen" class="btn-back">Kembali</a>
            </div>
        </form>
    </div>
</div>
