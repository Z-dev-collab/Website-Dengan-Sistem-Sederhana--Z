<?php
// koneksi ke database
include '../config/koneksi.php'; // pastikan file config.php berisi koneksi ke database


// cek apakah form disubmit dengan method POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ambil data dari form
    $nama_dosen      = mysqli_real_escape_string($conn, $_POST['nama_dosen']);
    $nomor_hp     = mysqli_real_escape_string($conn, $_POST['nomor_hp']);
    $alamat    = mysqli_real_escape_string($conn, $_POST['alamat']);
    $id_mapel  = mysqli_real_escape_string($conn, $_POST['id_mapel']);

    // validasi sederhana: cek jika ada yang kosong
    if (empty($nama_dosen) || empty($nomor_hp) || empty($alamat) || empty($id_mapel)) {
        echo "<script>alert('Semua field harus diisi!'); window.location.href='../?page=tambah_nama_dosen';</script>";
        exit;
    }

    // query insert data        
    $query = "INSERT INTO nama_dosen (nama_dosen, alamat, nomor_hp, id_mapel)
              VALUES ('$nama_dosen', '$alamat', '$nomor_hp', '$id_mapel')";

    if (mysqli_query($conn, $query)) {
        // jika sukses
        echo "<script>alert('Data Nama Dosen berhasil ditambahkan!'); window.location.href='../?page=view_nama_dosen';</script>";
    } else {
        // jika gagal
        echo "<script>alert('Gagal menambahkan Data Nama Dosen masuk: " . mysqli_error($conn) . "'); window.location.href='../?page=tambah_nama_dosen';</script>";
    }

    // tutup koneksi
    mysqli_close($conn);
} else {
    // jika akses langsung tanpa submit
    header("Location: ../?page=view_nama_dosen");
    exit;
}
?>
