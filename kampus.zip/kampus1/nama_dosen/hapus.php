<?php
// koneksi ke database
include '../config/koneksi.php';

// ambil ID dari parameter URL
if (isset($_GET['id_dosen'])) {
    $id_dosen = $_GET['id_dosen'];

    // query hapus data
    $query = "DELETE FROM nama_dosen WHERE id_dosen='$id_dosen'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        // jika berhasil hapus, kembali ke halaman view_pemasukan
        header("Location: ../index.php?page=view_nama_dosen&pesan=hapus_sukses");
        exit;
    } else {
        echo "Gagal menghapus data: " . mysqli_error($conn);
    }
} else {
    echo "ID tidak ditemukan!";
}
?>
