<?php
include '../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_dosen     = $_POST['id_dosen'];
    $nama_dosen     = $_POST['nama_dosen'];
    $nomor_hp   = $_POST['nomor_hp'];
    $alamat    = $_POST['alamat'];
    $id_mapel = $_POST['id_mapel'];

    $query = "UPDATE nama_dosen SET 
                nama_dosen='$nama_dosen',
                alamat='$alamat',
                nomor_hp='$nomor_hp',
                id_mapel='$id_mapel'
                WHERE id_dosen = '$id_dosen'";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Data dosen berhasil diperbarui!'); window.location.href='../?page=view_nama_dosen';</script>";
    } else {
        echo "<script>alert('Gagal mengupdate data: " . mysqli_error($conn) . "'); window.history.back();</script>";
    }
} else {
    header("Location: ../?page=view_nama_dosen");
    exit;
}
?>
