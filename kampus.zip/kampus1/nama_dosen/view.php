<div class="content">
    <div class="data-siswa">
        <div class="header-table">
            <h2>Data Dosen</h2>
            <a href="?page=tambah_nama_dosen" class="btn-tambah">+ Tambah Data Dosen</a>
        </div>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NIDN</th>
                        <th>Nama Dosen</th>
                        <th>Nomor Hp</th>
                        <th>Alamat</th>
                        <th>Nama Mata Kuliah</th>
                        <th>Aksi</th>
                    </tr>   
                </thead>
                <tbody>
                <?php
                // ambil data mata kuliah
                $query = "SELECT n.id_dosen, n.nama_dosen, n.nomor_hp, n.alamat, d.nama_mapel FROM nama_dosen AS n
                        INNER JOIN mata_kuliah AS d ON n.id_mapel = d.id_mapel";
                $result = mysqli_query($conn, $query);
                $no = 1;

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                                <td>".$no++."</td>
                                <td>".$row['id_dosen']."</td>
                                <td>".$row['nama_dosen']."</td>
                                <td>".$row['nomor_hp']."</td>
                                <td>".$row['alamat']."</td>
                                <td>".$row['nama_mapel']."</td>
                                <td class='table-action'>
                                    <a class='btn-edit' href='?page=edit_nama_dosen&id_dosen=".$row['id_dosen']."' text-decoration:none;'>Edit</a> 
                                    <a class='btn-hapus' href='nama_dosen/hapus.php?id_dosen=".$row['id_dosen']."' 
                                       text-decoration:none;' 
                                       onclick=\"return confirm('Yakin ingin menghapus data ini?');\">Hapus</a>
                                </td>
                              </tr>";
                    }
                } else {
                    echo "<tr>
                            <td colspan='8' style='text-align:center;'>Data Dosen belum tersedia.</td>
                          </tr>";
                }

                // tutup koneksi
                mysqli_close($conn);
                ?>
            </tbody>
            </table>
    </div>
</div>