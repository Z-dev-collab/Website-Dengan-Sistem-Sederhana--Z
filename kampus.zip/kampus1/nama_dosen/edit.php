<?php
include '../config/koneksi.php';

// Ambil data berdasarkan ID yang dikirim dari tombol Edit
if (isset($_GET['id_dosen'])) {
    $id_dosen = $_GET['id_dosen'];
    // Menggunakan INNER JOIN agar data mata kuliah juga terbawa (opsional, tapi lebih baik)
    $query = "SELECT n.id_dosen, n.nama_dosen, n.nomor_hp, n.alamat, n.id_mapel FROM nama_dosen AS n
            WHERE n.id_dosen = '$id_dosen'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $data = mysqli_fetch_assoc($result); 
    } else {
        echo "<script>alert('Data dosen tidak ditemukan!'); window.location.href='?page=view_nama_dosen';</script>";
        exit;
    }
} else {
    echo "<script>alert('ID Dosen tidak ditemukan!'); window.location.href='?page=view_nama_dosen';</script>";
    exit;
}
?>

<div class="content">
    <div class="form-container">
        <h2>Edit Data Dosen</h2>
        <form action="nama_dosen/proses_edit.php" method="POST">

            <!-- ID hidden untuk proses update -->
            <input type="hidden" name="id_dosen" value="<?= $data['id_dosen']; ?>">

            <div class="form-group">
                <label for="nama_dosen">Nama Dosen</label>
                <input type="text" id="nama_dosen" name="nama_dosen" value="<?= $data['nama_dosen']; ?>" required>
            </div>

            <div class="form-group">
                <label for="nomor_hp">Nomor Hp</label>
                <input type="text" id="nomor_hp" name="nomor_hp" value="<?= $data['nomor_hp']; ?>" required>
            </div>

            <div class="form-group">
                <label for="alamat">Alamat</label>
                <input type="text" id="alamat" name="alamat" value="<?= $data['alamat']; ?>" required>
            </div>

            <div class="form-group">
                <label for="id_mapel">Mata Kuliah</label>
                <select name="id_mapel" id="id_mapel">
                    <option value="">-- Pilih Mata Kuliah --</option>
                    <?php 
                    $mata_kuliah = mysqli_query($conn, "SELECT * FROM mata_kuliah");
                    while($m = mysqli_fetch_assoc($mata_kuliah)) {
                        $selected = ($m['id_mapel'] == $data['id_mapel']) ? "selected" : "";
                        echo "<option value='{$m['id_mapel']}' $selected>{$m['nama_mapel']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="button-group">
                <button type="submit" class="btn-submit">Simpan</button>
                <a href="?page=view_nama_dosen" class="btn-back">Kembali</a>
            </div>
        </form>
    </div>
</div>
