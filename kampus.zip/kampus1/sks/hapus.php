<?php
// koneksi ke database
include '../config/koneksi.php';

// ambil ID dari parameter URL
if (isset($_GET['id_sks'])) {
    $id_sks = $_GET['id_sks'];

    // query hapus data
    $query = "DELETE FROM sks WHERE id_sks='$id_sks'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        // jika berhasil hapus, kembali ke halaman view_pemasukan
        header("Location: ../index.php?page=view_sks&pesan=hapus_sukses");
        exit;
    } else {
        echo "Gagal menghapus data: " . mysqli_error($conn);
    }
} else {
    echo "ID tidak ditemukan!";
}
?>
