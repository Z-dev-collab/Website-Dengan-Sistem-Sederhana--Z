<?php
// koneksi ke database
include '../config/koneksi.php'; // pastikan file config.php berisi koneksi ke database


// cek apakah form disubmit dengan method POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ambil data dari form
    $id_dosen      = mysqli_real_escape_string($conn, $_POST['id_dosen']);
    $id_mhs    = mysqli_real_escape_string($conn, $_POST['id_mhs']);
    $status  = mysqli_real_escape_string($conn, $_POST['status']);

    // validasi sederhana: cek jika ada yang kosong
    if (empty($id_dosen) || empty($id_mhs)) {
        echo "<script>alert('Semua field harus diisi!'); window.location.href='../?page=tambah_sks';</script>";
        exit;
    }

    // query insert data        
    $query = "INSERT INTO sks (id_dosen, id_mhs, status)
              VALUES ('$id_dosen', '$id_mhs', '$status')";

    if (mysqli_query($conn, $query)) {
        // jika sukses
        echo "<script>alert('Data Satuan Kredit Semester berhasil ditambahkan!'); window.location.href='../?page=view_sks';</script>";
    } else {
        // jika gagal
        echo "<script>alert('Gagal menambahkan Data Satuan Kredit Semester masuk: " . mysqli_error($conn) . "'); window.location.href='../?page=tambah_sks';</script>";
    }

    // tutup koneksi
    mysqli_close($conn);
} else {
    // jika akses langsung tanpa submit
    header("Location: ../?page=view_sks");
    exit;
}
?>
