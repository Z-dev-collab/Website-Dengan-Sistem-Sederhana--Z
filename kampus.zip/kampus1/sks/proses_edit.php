<?php
include '../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_sks     = $_POST['id_sks'];
    $id_dosen     = $_POST['id_dosen'];
    $id_mhs   = $_POST['id_mhs'];

    $query = "UPDATE sks SET 
                id_dosen='$id_dosen',
                id_mhs='$id_mhs'
                WHERE id_sks = '$id_sks'";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Data barang masuk berhasil diperbarui!'); window.location.href='../?page=view_sks';</script>";
    } else {
        echo "<script>alert('Gagal mengupdate data: " . mysqli_error($conn) . "'); window.history.back();</script>";
    }
} else {
    header("Location: ../?page=view_sks");
    exit;
}
?>
