<div class="content">
    <div class="data-siswa">
        <div class="header-table">
            <h2>Data Satuan Kredit Semester</h2>
            <a href="?page=tambah_sks" class="btn-tambah">+ Tambah Data Satuan Kredit Semester</a>
        </div>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>ID Satuan Kredit Semester</th>
                        <th>Nama Dosen</th>
                        <th>Nama Mahasiswa</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>   
                </thead>
                <tbody>
                <?php
                // ambil data barang_masuk
                // $query = "SELECT * FROM barang_masuk ORDER BY tanggal_masuk ASC";
                $query = "SELECT s.id_sks, n.nama_dosen, m.nama, status FROM sks s
                            INNER JOIN nama_dosen AS n on s.id_dosen = n.id_dosen
                            INNER JOIN data_mahasiswa AS m ON s.id_mhs = m.id_mhs
                            ORDER BY status ASC";
                $result = mysqli_query($conn, $query);
                $no = 1;

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                                <td>".$no++."</td>
                                <td>".$row['id_sks']."</td>
                                <td>".$row['nama_dosen']."</td>
                                <td>".$row['nama']."</td>
                                <td>".$row['status']."</td>
                                <td class='table-action'>
                                    <a class='btn-edit' href='?page=edit_sks&id_sks=".$row['id_sks']."' text-decoration:none;'>Edit</a> 
                                    <a class='btn-hapus' href='sks/hapus.php?id_sks=".$row['id_sks']."' 
                                       text-decoration:none;' 
                                       onclick=\"return confirm('Yakin ingin menghapus data ini?');\">Hapus</a>
                                </td>
                                    </tr>";
                    }
                } else {
                    echo "<tr>
                            <td colspan='8' style='text-align:center;'>Data Barang Masuk belum tersedia.</td>
                        </tr>";
                }

                // tutup koneksi
                mysqli_close($conn);
                ?>
            </tbody>
            </table>
    </div>
</div>