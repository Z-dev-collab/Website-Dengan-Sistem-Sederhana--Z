<?php
include '../config/koneksi.php';

// Ambil data berdasarkan ID yang dikirim dari tombol Edit
if (isset($_GET['id_sks'])) {
    $id_sks = $_GET['id_sks'];
    $query = "SELECT * FROM sks WHERE id_sks = '$id_sks'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $data = mysqli_fetch_assoc($result); 
    } else {
        echo "<script>alert('Data SKS tidak ditemukan!'); window.location.href='?page=view_sks';</script>";
        exit;
    }
} else {
    echo "<script>alert('ID SKS tidak ditemukan!'); window.location.href='?page=view_sks';</script>";
    exit;
}
?>

<div class="content">
    <div class="form-container">
        <h2>Edit Data Satuan Kredit Semester</h2>
        <form action="sks/proses_edit.php" method="POST">

            <!-- ID hidden untuk proses update -->
            <input type="hidden" name="id_sks" value="<?= $data['id_sks']; ?>">

            <div class="form-group">
                <label for="id_dosen">Nama Dosen</label>
                <select name="id_dosen" id="id_dosen" required>
                    <?php 
                    $dosen = mysqli_query($conn, "SELECT * FROM nama_dosen");
                    while($n = mysqli_fetch_assoc($dosen)) {
                        $sel = ($n['id_dosen'] == $data['id_dosen']) ? "selected" : "";
                        echo "<option value='{$n['id_dosen']}' $sel>{$n['nama_dosen']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="id_mhs">Nama Mahasiswa</label>
                <select name="id_mhs" id="id_mhs" required>
                    <?php 
                    $mhs = mysqli_query($conn, "SELECT * FROM data_mahasiswa");
                    while($m = mysqli_fetch_assoc($mhs)) {
                        $sel = ($m['id_mhs'] == $data['id_mhs']) ? "selected" : "";
                        echo "<option value='{$m['id_mhs']}' $sel>{$m['nama']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="status">Status Verifikasi</label>
                <select name="status" id="status" required>
                    <option value="Proses" <?= ($data['status'] == 'Proses') ? 'selected' : ''; ?>>Proses</option>
                    <option value="Selesai" <?= ($data['status'] == 'Selesai') ? 'selected' : ''; ?>>Selesai</option>
                </select>
            </div>

            <div class="button-group">
                <button type="submit" class="btn-submit">Simpan</button>
                <a href="?page=view_sks" class="btn-back">Kembali</a>
            </div>
        </form>
    </div>
</div>
