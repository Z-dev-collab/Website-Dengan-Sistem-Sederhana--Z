<div class="content">
    <div class="form-container">
        <h2>Tambah Data SKS</h2>
        <form action="sks/proses_tambah.php" method="POST">
            
            <div class="form-group">
                <label for="id_dosen">Nama Dosen</label>
                <select name="id_dosen" id="id_dosen" required>
                    <option value="">-- Pilih Nama Dosen --</option>
                    <?php 
                    $nama_dosen = mysqli_query($conn, "SELECT * FROM nama_dosen");
                    while($n = mysqli_fetch_assoc($nama_dosen)) {
                        echo "<option value='{$n['id_dosen']}'>{$n['nama_dosen']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="id_mhs">Nama Mahasiswa</label>
                <select name="id_mhs" id="id_mhs" required>
                    <option value="">-- Pilih Nama Mahasiswa --</option>
                    <?php 
                    $data_mahasiswa = mysqli_query($conn, "SELECT * FROM data_mahasiswa");
                    while($m = mysqli_fetch_assoc($data_mahasiswa)) {
                        echo "<option value='{$m['id_mhs']}'>{$m['nama']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="status">Status</label>
                <!-- Tampilan untuk user -->
                <input type="text" value="Waiting" disabled>
                <!-- Data yang benar-benar dikirim ke server -->
                <input type="hidden" name="status" value="Waiting">
            </div>

            <div class="button-group">
                <button type="submit" class="btn-submit">Simpan</button>
                <a href="?page=view_sks" class="btn-back">Kembali</a>
            </div>
        </form>
    </div>
</div>
