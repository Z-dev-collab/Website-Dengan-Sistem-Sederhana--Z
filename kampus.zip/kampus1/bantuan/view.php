<div class="content">
    <div class="data-siswa">
        <h2 style="margin-bottom: 10px;">Pusat Bantuan & FAQ</h2>
        <p style="color: #666; margin-bottom: 30px;">Temukan jawaban untuk pertanyaan umum terkait Sistem Informasi Kampus di bawah ini.</p>

        <div style="margin-bottom: 25px; padding-bottom: 15px; border-bottom: 1px solid #eee;">
            <h4 style="color: #006837; margin-bottom: 8px; font-size: 16px;">1. Bagaimana cara menambahkan data mahasiswa baru?</h4>
            <p style="color: #444; font-size: 14px; line-height: 1.6;">Masuk ke menu <strong>Data Kampus > Mahasiswa</strong>, lalu klik tombol hijau bertuliskan <strong>+ Tambah Data Mahasiswa</strong> di pojok kanan atas tabel. Isi form dengan lengkap lalu klik Simpan.</p>
        </div>

        <div style="margin-bottom: 25px; padding-bottom: 15px; border-bottom: 1px solid #eee;">
            <h4 style="color: #006837; margin-bottom: 8px; font-size: 16px;">2. Saya lupa password untuk login, apa yang harus dilakukan?</h4>
            <p style="color: #444; font-size: 14px; line-height: 1.6;">Pada halaman login, Anda dapat mengklik link <strong>"Hubungi Admin"</strong> di bagian bawah form untuk menghubungi admin via WhatsApp dan meminta reset password.</p>
        </div>

        <div style="margin-bottom: 25px; padding-bottom: 15px; border-bottom: 1px solid #eee;">
            <h4 style="color: #006837; margin-bottom: 8px; font-size: 16px;">3. Bagaimana cara mencari data dosen atau mahasiswa dengan cepat?</h4>
            <p style="color: #444; font-size: 14px; line-height: 1.6;">Gunakan menu <strong>Search</strong> di sidebar sebelah kiri. Anda dapat langsung mengetikkan nama mahasiswa atau dosen untuk menemukan informasi spesifik mereka dengan cepat.</p>
        </div>

        <div style="margin-bottom: 25px; padding-bottom: 15px; border-bottom: 1px solid #eee;">
            <h4 style="color: #006837; margin-bottom: 8px; font-size: 16px;">4. Apakah data yang sudah dihapus bisa dikembalikan?</h4>
            <p style="color: #444; font-size: 14px; line-height: 1.6;">Tidak, fitur penghapusan bersifat permanen. Harap berhati-hati saat mengklik tombol Hapus berwarna merah. Pastikan Anda benar-benar ingin menghapus data tersebut.</p>
        </div>

        <div style="margin-top: 40px; background: #f9f9f9; padding: 20px; border-radius: 10px; border-left: 5px solid #efa00b;">
            <h4 style="margin-bottom: 10px; color: #333;">Masih Butuh Bantuan?</h4>
            <p style="font-size: 14px; color: #555;">Jika Anda mengalami kendala teknis lainnya atau menemukan <i>bug</i> di dalam sistem, silakan hubungi tim IT Support Kampus di nomor <a href="https://wa.me/6285835153723" style="color: #006837; font-weight: bold; text-decoration: none;">WhatsApp Admin IT</a>.</p>
        </div>
    </div>
</div>
