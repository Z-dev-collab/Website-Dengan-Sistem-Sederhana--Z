<nav>
    <div class="title"></div>
    <div class="user">
        <h2>Halo, Zoharyadi</h2>
        <a href="logout.php">Logout</a>
    </div>
</nav>