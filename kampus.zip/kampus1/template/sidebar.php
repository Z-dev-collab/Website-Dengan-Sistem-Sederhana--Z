<?php
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
?>
<aside>
    <div class="logo">
        <div class="profil-user">JF</div>
        <H1>Kampus <span>APP</span></H1>
    </div>
    <div class="menu">
        <ul>
            <li><a class="<?= ($page == 'dashboard' || $page == '') ? 'active' : '' ?>" href="?page=dashboard">Dashboard</a></li>
            <li><a class="<?= ($page == 'view_search') ? 'active' : '' ?>" href="?page=view_search">Search</a></li>
        </ul>
    </div>
    <h3>Data Kampus </h3>
    <div class="menu">
        <ul>
            <li><a class="<?= (strpos($page, 'mahasiswa') !== false) ? 'active' : '' ?>" href="?page=view_data_mahasiswa">Mahasiswa</a></li>
            <li><a class="<?= (strpos($page, 'mata_kuliah') !== false) ? 'active' : '' ?>" href="?page=view_mata_kuliah">Mata Kuliah</a></li>
            <li><a class="<?= (strpos($page, 'nama_dosen') !== false) ? 'active' : '' ?>" href="?page=view_nama_dosen">Dosen</a></li>
            <li><a class="<?= (strpos($page, 'sks') !== false) ? 'active' : '' ?>" href="?page=view_sks">Satuan Kredit Semester</a></li>
            <li><a class="<?= (strpos($page, 'user') !== false) ? 'active' : '' ?>" href="?page=view_user">User Kampus</a></li>
        </ul>
    </div>
    <h3>LAYANAN</h3>
    <div class="menu">
        <ul>
            <li><a href="https://uis.ac.id/">Tentang Kampus</a></li>
            <li><a class="<?= (strpos($page, 'bantuan') !== false) ? 'active' : '' ?>" href="?page=view_bantuan">Bantuan</a></li>
        </ul>
    </div>
    <h3>LAINNYA</h3>
</aside>