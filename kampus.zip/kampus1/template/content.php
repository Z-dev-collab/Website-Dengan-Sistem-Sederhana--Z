<div class="content">
    <div class="cards">
        <div class="card siswa">
            <h3>Mahasiswa</h3>
            <p><span>59</span> Orang</p>
        </div>
        <div class="card buku">
            <h3>Matkul</h3>
            <p><span>132 </span> Mata Kuliah</p>
        </div>
        <div class="card peminjaman">
            <h3>Dosen</h3>
            <p><span>12</span> Orang</p>
        </div>
    
    </div>
</div>