
<?php

$conn = mysqli_connect("localhost", "root", "", "dbmhs");

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
} else {
    echo "";
}

?>

