<?php
// koneksi ke database
include '../config/koneksi.php';

// ambil ID dari parameter URL
if (isset($_GET['id_user'])) {
    $id_user = $_GET['id_user'];

    // query hapus data
    $query = "DELETE FROM users WHERE id_user='$id_user'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        // jika berhasil hapus, kembali ke halaman view_pemasukan
        header("Location: ../index.php?page=view_user&pesan=hapus_sukses");
        exit;
    } else {
        echo "Gagal menghapus data: " . mysqli_error($conn);
    }
} else {
    echo "ID tidak ditemukan!";
}
?>
