<?php
include '../config/koneksi.php';

if (isset($_GET['id_user'])) {
    $id_user = $_GET['id_user'];
    $query = "SELECT u.id_user, u.username, u.nama, u.status FROM users u
                WHERE u.id_user = '$id_user'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $data = mysqli_fetch_assoc($result); 
    } else {
        echo "<script>alert('Data user tidak ditemukan!'); window.location.href='?page=view_user';</script>";
        exit;
    }
} else {
    echo "<script>alert('ID user tidak ditemukan!'); window.location.href='?page=view_user';</script>";
    exit;
}
?>

<div class="content">
    <div class="form-container">
        <h2>Edit Data User</h2>
        <form action="user/proses_edit.php" method="POST">
            <input type="hidden" name="id_user" value="<?= $data['id_user']; ?>">

            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" value="<?= $data['username']; ?>" required>
            </div>

            <div class="form-group">
                <label for="nama">Nama</label>
                <input type="text" id="nama" name="nama" value="<?= $data['nama']; ?>" required>
            </div>

            <div class="form-group">
                <label for="status">Status</label>
                <select id="status" name="status" required>
                    <option value="">-- Pilih Status --</option>
                    <option value="Aktif" <?= ($data['status'] == 'Aktif') ? 'selected' : ''; ?>>Aktif</option>
                    <option value="Tidak Aktif" <?= ($data['status'] == 'Tidak Aktif') ? 'selected' : ''; ?>>Tidak Aktif</option>
                </select>
            </div>

            <div class="button-group">
                <button type="submit" class="btn-submit">Simpan</button>
                <a href="?page=view_user" class="btn-back">Kembali</a>
            </div>
        </form>
    </div>
</div>
