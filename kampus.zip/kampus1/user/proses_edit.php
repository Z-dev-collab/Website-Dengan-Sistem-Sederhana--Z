<?php
include '../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_user     = $_POST['id_user'];
    $username = $_POST['username'];
    $nama = $_POST['nama'];
    $status = $_POST['status'];

    $query = "UPDATE users SET 
                username='$username',
                nama='$nama',
                status='$status'
                WHERE id_user = '$id_user'";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Data User berhasil diperbarui!'); window.location.href='../?page=view_user';</script>";
    } else {
        echo "<script>alert('Gagal mengupdate data: " . mysqli_error($conn) . "'); window.history.back();</script>";
    }
} else {
    header("Location: ../?page=view_user");
    exit;
}
?>
