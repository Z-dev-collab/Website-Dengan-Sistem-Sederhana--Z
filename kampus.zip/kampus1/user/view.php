<div class="content">
    <div class="data-siswa">
        <div class="header-table">
            <h2>Data User Kampus</h2>
        </div>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>ID User</th>
                        <th>Username</th>
                        <th>Nama</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>   
                </thead>
                <tbody>
                <?php
                // ambil data barang_masuk
                // $query = "SELECT * FROM barang_masuk ORDER BY tanggal_masuk ASC";
                $query = "SELECT u.id_user, u.username, u.nama, status FROM users u
                        ORDER BY status ASC";
                $result = mysqli_query($conn, $query);
                $no = 1;

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                                <td>".$no++."</td>
                                <td>".$row['id_user']."</td>
                                <td>".$row['username']."</td>
                                <td>".$row['nama']."</td>
                                <td>".$row['status']."</td>
                                <td class='table-action'>
                                    <a class='btn-edit' href='?page=edit_user&id_user=".$row['id_user']."' text-decoration:none;'>Edit</a> 
                                    <a class='btn-hapus' href='user/hapus.php?id_user=".$row['id_user']."' 
                                       text-decoration:none;' 
                                       onclick=\"return confirm('Yakin ingin menghapus data ini?');\">Hapus</a>
                                </td>
                                    </tr>";
                    }
                } else {
                    echo "<tr>
                            <td colspan='8' style='text-align:center;'>Data User belum tersedia.</td>
                        </tr>";
                }

                // tutup koneksi
                mysqli_close($conn);
                ?>
            </tbody>
            </table>
    </div>
</div>